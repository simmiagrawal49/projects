<?php
    ob_start();
    session_start();
    session_write_close();
    if(!isset($_SESSION['active']))
    {
        header("location: index.php?notlog=true");
        exit();
    }
    if($_SESSION['debug'])
    {
        error_reporting(E_ALL);
        echo "<div><center>Debug Session Active</center></div><hr/>";
    }
?>
<?php
    
    $a=$_POST;
    $b=array();
    
    foreach($a as $i=>$j)
    {
        if(strlen($j)>0)
        {
            $b[]=strtolower("'$i'").": new RegExp('$j*')";
        }
    }
    
    $c=implode(", ", $b);
    
    $d="{"."$c"."}";
    
    $e="db.insignia.find($d, {"."_id: 0"."});";
    
    file_put_contents ( "searchin" , "$e" );
    if($_POST['debug'])
    {
        $r=0;
    }
    else
    {
        shell_exec("mongo < searchin > searchout");
        $r=shell_exec("echo %ERRORLEVEL%");
    }
    if((int)($r)!=0)
    {
        header("location: search.php?last=false");
        exit();
    }
    else
        {
        header("location: search.php?last=true");
        exit();
    }
?>
<?php
    
    
    $id=strtolower("'repid': '$r'");
    $d="{"."$id"."}";
    $e="db.insignia.find($d, {"."_id: 0"."});";
    file_put_contents ( "repin" , "$e" );
    if($debug)
    {
        $s=0;
    }
    else
    {
        shell_exec("mongo < repin > repout");
        $s=shell_exec("echo %ERRORLEVEL%");
    }
    $data = file_get_contents("repout");
    $data = explode("\n", $data);
    $len = count($data);
    $data = array_slice($data, 2, $len-4);
    $r = json_decode($data[0], true);
    
?>
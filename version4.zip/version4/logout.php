<?php
    ob_start();
    session_start();
    unset($_SESSION['active']);
    unset($_SESSION['debug']);
    unset($_SESSION);
    session_write_close();
    session_destroy();
    header("location: index.php?logout=true");
    exit();
?>
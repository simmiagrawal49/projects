<?php
    require_once("sess.php");
    $data = file_get_contents("searchout");
    $data = explode("\n", $data);
    $len = count($data);
    $data = array_slice($data, 2, $len-4);
?>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
        <title>Search Page</title>
<style>

/*body font specified*/
body {font-family: "Lato", sans-serif;}

#bgColor {
height : 700px;
background : #33FF33;
background : linear-gradient(#ff8000, #ffffff, #008000);}

 	.main{
                width: 960px;
                height: auto;
                //background-color: aliceblue;
            }
            #sub{
                
                width: 600px;
                height: auto;
            }



</style>
</head>

<body id='bgColor'>
<table id='main' border="1"> <!--Table with 4 rows and 4 columns-->
<tbody>
					<tr>
					<td class="main">
                        Serial no
                    </td> 
                    <td class="main">
                        Report No
                    </td>
                    <td>
                      FIR No. of Information
                    </td>
                    <td>
                      IPC
                    </td>
                    <td>
                      Date of Event
                    </td>
                    <td>
                      Case Diary No.
                    </td>
                    <td class="main">
                        First name of Suspect 
                    </td> 
                    <td class="main">
                        Final Report No.
                    </td> 
					</tr>
                <?php
                    $r=null;
                    $s=null;
                    $i=1;
                    foreach($data as $s)
                    {
                        $r = json_decode($s, true);
                ?>
				<tr>
				<td class="main">
                    <?php echo $i;?>
                </td> 
                <td class="main">
                    <?php echo "<a href='showrecord.php?rep=".$r['repid']."'>".$r['repid']."</a>";?>
                </td> 
                <td class="main">
                    <?php
                        if(strlen($r['a3'])>0)
                            echo $r['a3'];
                        else
                            echo "<i><b>empty</b></i>";
                    ?>
                </td>
                <td class="main">
                    <?php
                        if(strlen($r['b0'])>0)
                            echo $r['b0'];
                        else
                            echo "<i><b>empty</b></i>";
                    ?>
                </td>
                <td class="main">
                    <?php
                        if(strlen($r['c5'])>0)
                            echo $r['c5'];
                        else
                            echo "<i><b>empty</b></i>";
                    ?>
                </td>
                <td class="main">
                    <?php
                        if(strlen($r['c1'])>0)
                            echo $r['c1'];
                        else
                            echo "<i><b>empty</b></i>";
                    ?>
                </td>
                <td class="main">
                    <?php
                        if(strlen($r['f0'])>0)
                            echo $r['f0'];
                        else
                            echo "<i><b>empty</b></i>";
                    ?>
                </td>
                <td class="main">
                    <?php
                        if(strlen($r['m1'])>0)
                            echo $r['m1'];
                        else
                            echo "<i><b>empty</b></i>";
                    ?>
                </td> 
                </tr>
                <?php
                        ++$i;
                    }
                ?>
                </tbody>
</table>
<address>
<table style="width:100%;position:fixed;bottom:12px;border:3px solid #000000;">
<tr>
  <td style="text-align:left;"><a href="insert.php">Insert</a></td>
  <td style="text-align:center;"><a href="logout.php">LogOut</a></td>
  <td style="text-align:right;"><a href="search.php">Search</a></td>

</tr>
</table>
</address>
</body>
</html>

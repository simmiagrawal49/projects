<!DOCTYPE html>
<html class=" js boxshadow pointerevents placeholder" lang="en">
<head>


        <link rel="shortcut icon" href="http://arunabhverma.com/favicon.ico"> 
        <link rel="stylesheet" type="text/css" href="Custom%20Login%20Form%20Styling_files/style.css">
		<script src="Custom%20Login%20Form%20Styling_files/modernizr.js"></script>
		
		<style>
		
			<body {
				background: #563c55 no-repeat center top;
				background:url('login_bg.jpg');
				-webkit-background-size: cover;
				-moz-background-size: cover;
				background-size: cover;
			}
			.container > header h1,
			.container > header h2 {
				color: #fff;
				text-shadow: 0 1px 1px rgba(0,0,0,0.7);
			}
		</style>
    </head>
    <body style =backgroundimage:url("Custom%20Login%20Form%20Styling_files/login_bg")>


			<section class="main">
				<form class="form-3">
				    <p class="clearfix">
				        <label for="login">Username</label>
				        <input name="login" id="login" placeholder="Username" type="text">
				    </p>
				    <p class="clearfix">
				        <label for="password">Password</label>
				        <input name="password" id="password" placeholder="Password" type="password"> 
				    </p>
				    <p class="clearfix">
				        <input name="remember" id="remember" type="checkbox">
				        <label for="remember">Remember me</label>
				    </p>
				    <p class="clearfix">
				        <input name="submit" value="Sign in" type="submit">
				    </p>       
				</form>
			</section>
			
        </div>
		
    
</body></html>
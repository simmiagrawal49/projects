<?php
    ob_start();
    session_start();
    session_write_close();
    if(isset($_GET['logout']))
    {
        echo "<center><h1>Logged out</h1></center>";
    }
    else if(isset($_GET['notlog']))
    {
        echo "<center><h1>Not logged in</h1></center>";
    }
    else if(isset($_SESSION['active']))
    {
        header("location: insert.php");
        exit();
    }
    if((isset($_POST['login']))&&(isset($_POST['password']))&&(isset($_POST['submit'])))
    {
        unset($_POST['submit']);
        if(($_POST['login']=="admin")&&($_POST['password']=="admin1234"))
        {
            session_start();
            $_SESSION['active']=true;
            if(isset($_POST['debugsess']))
            {
                $_SESSION['debug']=true;
            }
            else
            {
                $_SESSION['debug']=false;
            }
            session_write_close();
            header("location: insert.php");
            exit();
        }
        else
        {
            echo "<center><h1>Incorrect login</h1></center>";
        }
    }
?>
<!DOCTYPE html>
<html class=" js boxshadow pointerevents placeholder" lang="en">
<head>


        <link rel="shortcut icon" href="http://arunabhverma.com/favicon.ico"> 
        <link rel="stylesheet" type="text/css" href="style.css">
		<script src="modernizr.js"></script>
		
		<style>
		
			<body {
				background: #563c55 no-repeat center top;
				background-image: url("login_bg.jpg");
				-webkit-background-size: cover;
				-moz-background-size: cover;
				background-size: cover;
			}
			.container > header h1,
			.container > header h2 {
				color: #fff;
				text-shadow: 0 1px 1px rgba(0,0,0,0.7);
			}
		</style>
    </head>
    <body style='background-image: url("login_bg.jpg");'>

			<section class="main">
				<form class="form-3" method="POST">
				    <p class="clearfix">
				        <label for="login">Username</label>
				        <input name="login" id="login" placeholder="Username" type="text">
				    </p>
				    <p class="clearfix">
				        <label for="password">Password</label>
				        <input name="password" id="password" placeholder="Password" type="password"> 
				    </p>
				    <p class="clearfix">
				        <input name="remember" id="remember" type="checkbox">
				        <label for="remember">Remember me</label>
				    </p>
                    <p class="clearfix">
				        <input name="debugsess" id="debugsess" type="checkbox">
				        <label for="debugsess">Debug</label>
				    </p>
				    <p class="clearfix">
				        <input name="submit" value="Sign in" type="submit">
				    </p>       
				</form>
			</section>
			
        
	</div>
    
</body></html>
<?php
    
    if(isset($_POST['r']))
    {
        $r=$_POST['r'];
        unset($_POST['r']);
    }
    else
    {
        file_put_contents ( "insertin" , "db.insignia.find().length();" );
        if($_POST['debug'])
        {
            ;
        }
        else
        {
            shell_exec("mongo < insertin > insertout");
        }
        $r=(int)file_get_contents("insertout");
        ++$r;
    }
    $a=$_POST;
    $b=array();
    
    $id=strtolower("'repid': '$r'");
    $id="{"."$id"."}";
    
    foreach($a as $i=>$j)
    {
        $b[]=strtolower("'$i': '$j'");
    }
    $b[]=strtolower("'repid': '$r'");
    $c=implode(", ", $b);
    
    $d="{"."$c"."}";
    
    $e="db.insignia.update($id, $d, {upsert:true});";
    
    file_put_contents ( "insertin" , "$e" );
    if($_POST['debug'])
    {
        $r=0;
    }
    else
    {
        shell_exec("mongo < insertin > insertout");
        $r=shell_exec("echo %ERRORLEVEL%");
    }
    if((int)($r)!=0)
    {
        header("location: insert.php?last=false");
        exit();
    }
    else
        {
        header("location: insert.php?last=true");
        exit();
    }
?>